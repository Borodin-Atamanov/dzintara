#!/usr/bin/bash
#Author dev@Borodin-Atamanov.ru
#License: MIT
#https://telegram.org/dl/desktop/linux
source "${work_dir}/index.sh" fun
source "${work_dir}tasks/1.sh"

echo "●●● $script_subversion ●●●";
