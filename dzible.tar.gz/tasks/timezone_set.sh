#!/usr/bin/bash
#Author dev@Borodin-Atamanov.ru
#License: MIT
#https://telegram.org/dl/desktop/linux

timedatectl set-timezone Europe/Samara
timedatectl status | tac
