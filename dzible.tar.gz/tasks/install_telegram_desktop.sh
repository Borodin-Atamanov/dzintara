#!/usr/bin/bash
#Author dev@Borodin-Atamanov.ru
#License: MIT
#https://telegram.org/dl/desktop/linux

