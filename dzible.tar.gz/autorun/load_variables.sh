#!/usr/bin/bash
#Author dev@Borodin-Atamanov.ru
#License: MIT
#This file contains automaticaly generated variables, what using in target system in every run

#load functions and default variables
source "/home/i/bin/dzible/index.sh" fun

#One can find generated variables below

